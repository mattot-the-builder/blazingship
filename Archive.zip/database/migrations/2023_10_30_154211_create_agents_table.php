<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class () extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('agents', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('phone_number_e164');
            $table->string('address');
            $table->string('registration_date');
            $table->enum('role', ['agent', 'stockist', 'dropship'])->default('dropship');
            $table->unsignedInteger('total_sale')->default(0);
            $table->decimal('earning', 10, 2)->default(0.00);
            $table->string('payment_information');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('agents');
    }
};
